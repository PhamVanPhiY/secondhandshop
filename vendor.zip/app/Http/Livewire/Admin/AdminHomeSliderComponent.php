<?php

namespace App\Http\Livewire\Admin;

use Livewire\Component;

class AdminHomeSliderComponent extends Component
{
    public function render()
    {
        return view('livewire.admin.admin-home-slider-component');
    }
}
