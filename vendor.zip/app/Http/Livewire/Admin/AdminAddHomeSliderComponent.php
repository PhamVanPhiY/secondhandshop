<?php

namespace App\Http\Livewire\Admin;

use Livewire\Component;

class AdminAddHomeSliderComponent extends Component
{
    public function render()
    {
        return view('livewire.admin.admin-add-home-slider-component');
    }
}
