<div>
   <h1>User Customer Dashboard</h1>
</div>
<?php /**PATH C:\xampp\htdocs\shop-secondhand\resources\views/livewire/user/user-dashboard-component.blade.php ENDPATH**/ ?>