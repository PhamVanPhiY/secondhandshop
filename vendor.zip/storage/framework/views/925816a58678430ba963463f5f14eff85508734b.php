
<main id="main" class="main-site">

    <div class="container">

        <div class="wrap-breadcrumb">
            <ul>
                <li class="item-link"><a href="#" class="link">TRANG CHỦ</a></li>
                <li class="item-link"><span>THANH TOÁN</span></li>
            </ul>
        </div>
        <div class=" main-content-area">
            <form wire:submit.prevent="placeOrder">
                <div class="row">
                    <div class="col-md-12">
                        <div class="wrap-address-billing">
                            <h3 class="box-title">Địa chỉ thanh toán</h3>
                            <div class="billing-address">

                                <p class="row-in-form">
                                    <label for="fname">Họ<span>*</span></label>
                                    <input type="text" name="fname" value="" placeholder="Nhập họ của bạn" wire:model="firstname"/>
                                    <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </p>
                                <p class="row-in-form">
                                    <label for="lname">Tên<span>*</span></label>
                                    <input type="text" name="lname" value="" placeholder="Nhập tên của bạn" wire:model="lastname"/>
                                    <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </p>
                                <p class="row-in-form">
                                    <label for="email">Email :</label>
                                    <input type="email" name="email" value="" placeholder="Nhập email" wire:model="email"/>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </p>
                                <p class="row-in-form">
                                    <label for="phone">Số điện thoại :</label>
                                    <input type="text" name="phone" value="" placeholder="Nhập số điện thoại" wire:model="mobile"/>
                                    <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </p>
                               
                             
                                <p class="row-in-form">
                                    <label for="country">Quốc gia<span>*</span></label>
                                    <input type="text" name="country" value="" placeholder="Việt Nam" wire:model="country"/>
                                    <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </p>
                                <p class="row-in-form">
                                    <label for="province">Tỉnh:</label>
                                    <input type="text" name="province" value="" placeholder="Tỉnh" wire:model="province"/>
                                    <?php $__errorArgs = ['province'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </p>
                               
                                <p class="row-in-form">
                                    <label for="city">Địa chỉ chi tiết <span>*</span></label>
                                    <input type="text" name="city" value="" placeholder="Ghi chi tiết địa chỉ của bạn ?" wire:model="city"/>
                                    <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </p>
                             
                               

                            </div>

                        </div>
                    </div>
                   



                </div>

                <div class="summary summary-checkout">
                    <div class="summary-item payment-method">
                        <h4 class="title-box">Phương thức thanh toán</h4>
                        
                        <div class="choose-payment-methods">
                            <label class="payment-method">
                                <input name="payment-method" id="payment-method-bank" value="cod" type="radio" wire:model="paymentmode">
                                <span>Thanh toán khi giao hàng</span>
                                <span class="payment-desc">Đặt hàng thanh toán ngay khi nhận hàng</span>
                            </label>
                            <label class="payment-method">
                                <input name="payment-method" id="payment-method-visa" value="card" type="radio"  wire:model="paymentmode">
                                <span>Thanh toán bằng thẻ ghi nợ / thẻ tín dụng</span>
                                
                            </label>
                      
                            <?php $__errorArgs = ['paymentmode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <?php if(Session::has('checkout')): ?>
                        <p class="summary-info grand-total"><span>Tổng tiền :</span> <span class="grand-total-price">$<?php echo e(Session::get('checkout')['total' ]); ?></span></p>
                        <?php endif; ?>
                        <button type="submit" class="btn btn-primary">Đặt hàng</button>
                    </div>
                  
                </div>
            </form>
        </div>
    </div>





</main>
<?php /**PATH C:\xampp\htdocs\shop-secondhand\resources\views/livewire/checkout-component.blade.php ENDPATH**/ ?>