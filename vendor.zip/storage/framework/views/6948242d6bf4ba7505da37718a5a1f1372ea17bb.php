<div>
 <h1>Admin dashboard</h1>
</div>
<?php /**PATH C:\xampp\htdocs\shop-secondhand\resources\views/livewire/admin/admin-dashboard-component.blade.php ENDPATH**/ ?>