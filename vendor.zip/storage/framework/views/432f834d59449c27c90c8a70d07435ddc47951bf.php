<div>
   <div class="container" style="padding:  30px 0;">
    <div class="row">
        <div class="col-md-12">
            <div class="panel ">
                <h3>Thay đổi mật khẩu </h3>
            </div>
            <div class="panel-body">
                <?php if(Session::has('password_success')): ?>
                    <div class="alert alert_success" role="alert"><?php echo e(Session::get('password_success')); ?></div>
                <?php endif; ?>

                <?php if(Session::has('password_error')): ?>
                    <div class="alert alert_danger" role="alert"><?php echo e(Session::get('password_error')); ?></div>
                <?php endif; ?>
                <form class="form-horizontal" wire:submit.prevent="changePassword">
                    <div class="form-group">
                        <label for="" class="col-md-4 control-label">Mật khẩu hiện tại</label>
                        <div class="col-md-4">
                            <input type="password" placeholder="Mật khẩu hiện tại" class="form-control input-md" name="current_password" wire:model="current_password" />
                            <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-md-4 control-label">Mật khẩu mới</label>
                        <div class="col-md-4">
                            <input type="password" placeholder="Mật khẩu mới" class="form-control input-md" name="password" wire:model="password"/>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-md-4 control-label">Xác thực mật khẩu</label>
                        <div class="col-md-4">
                            <input type="password" placeholder="Vui lòng nhập lại mật khẩu mới" class="form-control input-md" name="password_confirmmation" wire:model="password_confirmation" />
                            <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-md-4 control-label"></label>
                        <div class="col-md-4">
                           <button type="submit" class="btn btn-primary"> Cập nhật</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

   </div>
</div>
<?php /**PATH C:\xampp\htdocs\shop-secondhand\resources\views/livewire/user/user-change-password-componet.blade.php ENDPATH**/ ?>