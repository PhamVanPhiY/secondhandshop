<main id="main" class="main-site">

    <div class="container">

        <div class="wrap-breadcrumb">
            <ul>
                <li class="item-link"><a href="#" class="link">SecondhandShop</a></li>
                <li class="item-link"><span>Giỏ hàng của bạn</span></li>
            </ul>
        </div>
        <div class=" main-content-area">
                <?php if(Cart::instance('cart')->count() > 0): ?>
            <div class="wrap-iten-in-cart">
                <?php if(Session::has('success_message')): ?>
                <div class="alert alert-success">
                    <strong><?php echo e(Session::get('success_message')); ?></strong>
                </div>
                <?php endif; ?>
                <?php if(Cart::instance('cart')->count() > 0): ?>
                <h3 class="box-title">Tên sản phẩm </h3>
                <ul class="products-cart">
                    <?php $__currentLoopData = Cart::instance('cart')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="pr-cart-item">
                        <div class="product-image">
                            <figure><img src="<?php echo e(('assets/images/products')); ?>/<?php echo e($item->model->image); ?>" alt=""></figure>
                        </div>
                        <div class="product-name">
                            <a class="link-to-product" href="#"><?php echo e($item->model->name); ?></a>
                        </div>
                        <div class="price-field produtc-price">
                            <p class="price">$<?php echo e($item->model->regular_price); ?></p>
                        </div>
                        <div class="quantity">
                            <div class="quantity-input">
                                <input type="text" name="product-quatity" value="<?php echo e($item->qty); ?>" data-max="120" pattern="[0-9]*">
                                <a class="btn btn-increase" href="#" wire:click.prevent="increaseQuantity('<?php echo e($item->rowId); ?>')"></a>
                                <a class="btn btn-reduce" href="#" wire:click.prevent="decreaseQuantity('<?php echo e($item->rowId); ?>')"></a>
                            </div>
                        </div>
                        <div class="price-field sub-total">
                            <p class="price">$<?php echo e($item->subtotal()); ?></p>
                        </div>
                        <div class="delete">
                            <a href="#" wire:click.prevent="destroy('<?php echo e($item->rowId); ?>')" class="btn btn-delete" title="">
                                <span>Delete from your cart</span>
                                <i class="fa fa-times-circle" aria-hidden="true"></i>
                            </a>
                        </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
                <?php else: ?>
                <p>Không có sản phẩm nào trong cửa hàng </p>
                <?php endif; ?>
            </div>

            <div class="summary">
                <div class="order-summary">
                    <h4 class="title-box">Order Summary</h4>
                    <p class="summary-info"><span class="title">Tổng tiền sản phẩm</span><b class="index">$<?php echo e(Cart::instance('cart')->subtotal()); ?></b></p>
                    <?php if(Session::has('coupon')): ?>
                         <p class="summary-info"><span class="title">Áp dụng mã (<?php echo e(Session::get('coupon')['code']); ?>) , trừ <a href="#" wire:click.prevent="removeCoupon"><i class="fa fa-times text-danger"></i></a> </span><b class="index"> - $<?php echo e(number_format($discount,2)); ?></b></p>
                         <hr>
                         <p class="summary-info"><span class="title">Tổng tiền ( đã giảm ) </span><b class="index">$<?php echo e(number_format($subtotalAfterDiscount,2)); ?></b></p>
                       
                         <hr>
                         <p class="summary-info"><span class="title">Thuế (<?php echo e(config('cart.tax')); ?>% ) </span><b class="index">$<?php echo e(number_format($taxAfterDiscount,2)); ?></b></p>
                         <hr>
                         <p class="summary-info"><span class="title">Tổng tiền cần thanh toán </span><b class="index">$<?php echo e(number_format($totalAfterDiscount,2)); ?></b></p>

                    <?php else: ?>
                    <p class="summary-info"><span class="title">Tiền vận chuyển</span><b class="index">$<?php echo e(Cart::instance('cart')->tax()); ?></b></p>
                    <p class="summary-info total-info "><span class="title">Tổng tiền thanh toán</span><b class="index">$<?php echo e(Cart::instance('cart')->total()); ?></b></p>
                    <?php endif; ?>
                    
                </div>

             
                <div class="checkout-info">
                <?php if(!Session::has('coupon')): ?> 
                    <label class="checkbox-field">
                        <input class="form-input " name="have-code" id="have-code" value="1" type="checkbox" wire:model="haveCouponCode"><span>Tôi có phiếu giảm giá </span>
                    </label>
                    <?php if($haveCouponCode == 1 ): ?>
                    <div class="summary-item">
                        <form action="" wire:submit.prevent="applyCouponCode">
                            <h4 class="title-box">Mã giảm giá</h4>
                            <?php if(Session::has('coupon_message')): ?>
                            <div class="alert alert-danger" role="danger">
                                <?php echo e(Session::get('coupon_message')); ?>

                            </div>
                            <?php endif; ?>
                            <p class="row-in-form">
                                <label for="coupon-code">Nhập vào mã giảm giá của bạn </label>
                                <input type="text" name="coupon-code" wire:model="couponCode" />
                            </p>
                            <button type="submit" class="btn btn-small ">Áp dụng</button>
                        </form>
                    </div>

                    <?php endif; ?>
                    <?php endif; ?>
                    <a class="btn btn-checkout" href="#" wire:click.prevent="checkout">Thanh toán</a>
                    <a class="link-to-shop" href="shop.html">Tiếp tục mua hàng<i class="fa fa-arrow-circle-right" aria-hidden="true"></i></a>
                </div>
                <div class="update-clear">
                    <a class="btn btn-clear" href="#" wire:click.prevent="destroyAll()">Xóa hết giỏ hàng</a>
                    <a class="btn btn-update" href="#">Cập nhật giỏ hàng</a>
                </div>
            </div>
            <?php else: ?> 
            <div class="text-center" style="padding:30px 0">
                <h1>Giỏ hàng của bạn đang trống</h1>
                <p>Hãy thêm vào giỏ hàng nào</p>
                <a href="/shop" class="btn btn-primary">Cửa hàng</a>
            </div>
            <?php endif; ?>


        </div>
    </div>

</main><?php /**PATH C:\xampp\htdocs\shop-secondhand\resources\views/livewire/cart-component.blade.php ENDPATH**/ ?>