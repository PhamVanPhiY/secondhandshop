<div>
  <div class="container" style="padding: 30px 0;">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Tạo sản phẩm giảm giá
                    </div>
                    <div class="panel-body">
                        <!-- <?php if(Session::has('message')): ?>
                        <div class="alert alert-success" role="alert"><?php echo e(Session::get('message')); ?></div>
                        <?php endif; ?> -->
                        <form action="" class="form-horizontal" >
                            <div class="form-group">
                                <label for="" class="col-md-4 control-label">Ghi chú</label>
                                <div class="col-md-4">
                                    <select class="form-control">
                                        <option value="0">Không hoạt động</option>
                                        <option value="1">Hoạt động</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="" class="col-md-4 control-label">Ngày giảm giá</label>
                                <div class="col-md-4">
                                    <input type="text" id="sale-date" placeholder="YYYY/MM/DD H:M:S" class="form-control input-md" />
                                </div> 
                            </div>

                            <div class="form-group">
                                <label for="" class="col-md-4 control-label"></label>
                                <div class="col-md-4">
                                   <button type="submit" class="btn btn-primary">Cập nhật</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
  </div>
  <?php $__env->startPush('scripts'); ?>


</div>


<?php /**PATH C:\xampp\htdocs\shop-secondhand\resources\views/livewire/admin/admin-sale-component.blade.php ENDPATH**/ ?>