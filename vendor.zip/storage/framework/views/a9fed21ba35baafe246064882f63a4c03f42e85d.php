<div>
    <style>
        nav svg {
            height: 20px;
        }
        nav .hidden{
            display: block !important;
        }
    </style>
    <div class="container" style="padding: 30px 0">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Tất cả đơn hàng
                    </div>
                    <div class="panel-body">
                        <?php if(Session::has('order_massage')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(Session::get('order_message')); ?>

                            </div>
                        <?php endif; ?>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>OrderId</th>
                                    <th>Tổng tiền sản phẩm </th>
                                    <th>Giảm </th>
                                    <th>Thuế</th>
                                    <th>Tổng tiền thanh toán</th>
                                    <th>Họ</th>
                                    <th>Tên</th>
                                    <th>Số điện thoại</th>
                                    <th>Email</th>
                                    <th>Thông tin</th>
                                    <th>Ngày đặt hàng</th>
                                    <th colspan="2" class="text-center">Hành động</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($order->id); ?></td>
                                    <td>$<?php echo e($order->subtotal); ?></td>
                                    <td>$<?php echo e($order->discount); ?></td>
                                    <td>$<?php echo e($order->tax); ?></td>
                                    <td>$<?php echo e($order->total); ?></td>
                                    <td><?php echo e($order->firstname); ?></td>
                                    <td><?php echo e($order->lastname); ?></td>
                                    <td><?php echo e($order->mobile); ?></td>
                                    <td><?php echo e($order->email); ?></td>
                                    <td><?php echo e($order->status); ?></td>
                                    <td><?php echo e($order->created_at); ?></td>
                                    <td><a href="<?php echo e(route('admin.orderdetails',['order_id' => $order->id])); ?>" class="btn btn-danger btn-sm">Chi tiết</a></td>
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-success btn-sm dropdown-toggle" type="button" data-toggle="dropdown">Trạng thái
                                            <span class="caret"></span>
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li><a href="#" wire:click.prevent="updateOrderStatus(<?php echo e($order->id); ?>,'Đã vận chuyển')">Đã vận chuyển</a></li>
                                                <li><a href="#" wire:click.prevent="updateOrderStatus(<?php echo e($order->id); ?>,'Đã hủy')">Đã hủy </a></li>
                                            </ul>
                                           
                                        </div>
                                    </td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($orders->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\shop-secondhand\resources\views/livewire/admin/admin-order-component.blade.php ENDPATH**/ ?>