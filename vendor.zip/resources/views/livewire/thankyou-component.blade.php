<main id="main" class="main-site">

		<div class="container">

			<div class="wrap-breadcrumb">
				
			</div>
		</div>
		
		<div class="container pb-60">
			<div class="row">
				<div class="col-md-12 text-center">
					<h2>Cảm ơn vì đã tin tưởng chúng tôi </h2>
                    
                    <a href="/shop" class="btn btn-submit btn-submitx">Tiếp tục mua hàng</a>
				</div>
			</div>
		</div><!--end container-->

	</main>